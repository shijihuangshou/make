else
----

Starts the else portion of an if block.

::

  else(expression)

See the :command:`if` command.
