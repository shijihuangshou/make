.. cmake-module:: ../../Modules/AndroidTestUtilities.cmake
